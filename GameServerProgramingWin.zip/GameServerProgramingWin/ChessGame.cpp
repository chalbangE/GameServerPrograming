#pragma once

#include "ChessGame.h"
#include "Chess.h"
#include "ClientCallback.h"

ChessGame::ChessGame()
{
	// backgroud.Draw(mdc, 0, 0, 800, 800, 0, 0, 800, 800); // �⺻ ����ȭ��
	backgroud.Load(TEXT("IMG/Background.png"));

	w = backgroud.GetWidth();
	h = backgroud.GetHeight();
}

void ChessGame::Drow(HDC& mdc)
{
	backgroud.Draw(mdc, 0, 0, w, h, 0, 0, w, h);

	for (Chess* ch : chesses) {
		ch->Drow(mdc);
	}
}

void ChessGame::AddChess()
{
	const std::string str{ "IMG/Momonga" + std::to_string(chesses.size() + 1) + ".png"};
	RECT rt{ 0, 0, 100, 100 };
	Chess* ch = new Chess{ str, rt, int(chesses.size() + 1) };

	chesses.push_back(ch);
}

void ChessGame::MinusChess(int my_id)
{
	// chesses[my_id] = nullptr;
}

void ChessGame::Move(int my_id, int add_x, int add_y)
{
	chesses[my_id]->Move(add_x, add_y);
}

void ChessGame::Move()
{
	wsabuf[0].len = BUFSIZE;
	DWORD recv_size{};
	DWORD recv_flag{ 0 };
	int res = WSARecv(server_s, wsabuf, 1, &recv_size, &recv_flag, nullptr, nullptr);
	if (res != 0)
		print_error("WSARecv", WSAGetLastError());

	Move(0, wsabuf[0].buf[0], wsabuf[0].buf[1]);
}

void ChessGame::PressKey(WPARAM wParam)
{
	buf[0] = wParam;
	buf[1] = '\0';
	wsabuf[0].buf = buf;
	wsabuf[0].len = static_cast<int>(strlen(buf)) + 1;
	if (wsabuf[0].len == 1) {
		bshutdown = true;
		return;
	}
	ZeroMemory(&wsaover, sizeof(wsaover));   // �ʱ�ȭ
	WSASend(server_s, wsabuf, 1, nullptr, 0, &wsaover, send_callback);

	Move();
		
	switch (wParam)
	{
	case VK_RIGHT: {
		Move(0, 1, 0);
		break;
	}
	case VK_LEFT: {
		Move(0, -1, 0);
		break;
	}
	case VK_UP: {
		Move(0, 0, -1);
		break;
	}
	case VK_DOWN: {
		Move(0, 0, 1);
		break;
	}
	case VK_ESCAPE: {
		exit(829);
	}
	default: {
		break;
	}
	}
}
